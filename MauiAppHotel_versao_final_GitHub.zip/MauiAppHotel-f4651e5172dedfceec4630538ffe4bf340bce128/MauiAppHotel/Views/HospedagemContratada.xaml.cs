using System.Globalization;

namespace MauiAppHotel.Views;

public partial class HospedagemContratada : ContentPage
{
    public HospedagemContratada(string acomodacao, int adultos, int criancas,
        DateTime checkin, DateTime checkout, int noites, decimal valorTotal)
    {
        InitializeComponent();

        lblAcomodacao.Text = acomodacao;
        lblAdultos.Text = adultos.ToString();
        lblCriancas.Text = criancas.ToString();
        lblCheckin.Text = checkin.ToString("dd/MM/yyyy");
        lblCheckout.Text = checkout.ToString("dd/MM/yyyy");
        lblNoites.Text = noites.ToString();
        lblTotal.Text = valorTotal.ToString("C", CultureInfo.GetCultureInfo("pt-BR"));
    }

    private async void OnNovaReservaClicked(object sender, EventArgs e)
    {
        await Navigation.PopToRootAsync();
    }

    private async void OnSobreClicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new SobrePage());
    }
}
