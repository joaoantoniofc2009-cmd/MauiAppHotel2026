namespace MauiAppHotel.Views;

public partial class ContratacaoHospedagem : ContentPage
{
    private readonly Dictionary<string, decimal> _diarias = new()
    {
        ["Suíte Standard"] = 180m,
        ["Suíte Luxo"] = 280m,
        ["Suíte Master"] = 400m
    };

    public ContratacaoHospedagem()
    {
        InitializeComponent();

        pckQuarto.ItemsSource = _diarias.Keys.ToList();
        pckQuarto.SelectedIndex = 0;

        dtpCheckin.MinimumDate = DateTime.Today;
        dtpCheckin.Date = DateTime.Today;
        dtpCheckout.MinimumDate = DateTime.Today.AddDays(1);
        dtpCheckout.Date = DateTime.Today.AddDays(1);
    }

    private void OnAdultosChanged(object sender, ValueChangedEventArgs e) =>
        lblAdultos.Text = ((int)e.NewValue).ToString();

    private void OnCriancasChanged(object sender, ValueChangedEventArgs e) =>
        lblCriancas.Text = ((int)e.NewValue).ToString();

    private async void OnAvancarClicked(object sender, EventArgs e)
    {
        if (pckQuarto.SelectedItem is not string acomodacao)
        {
            await DisplayAlert("Atenção", "Selecione uma acomodação.", "OK");
            return;
        }

        if (dtpCheckin.Date < DateTime.Today)
        {
            await DisplayAlert("Atenção", "A data de check-in não pode ser anterior a hoje.", "OK");
            return;
        }

        if (dtpCheckout.Date <= dtpCheckin.Date)
        {
            await DisplayAlert("Atenção", "O check-out deve acontecer depois do check-in.", "OK");
            return;
        }

        int noites = (dtpCheckout.Date - dtpCheckin.Date).Days;
        decimal valorTotal = _diarias[acomodacao] * noites;

        await Navigation.PushAsync(new HospedagemContratada(
            acomodacao,
            (int)stpAdultos.Value,
            (int)stpCriancas.Value,
            dtpCheckin.Date,
            dtpCheckout.Date,
            noites,
            valorTotal));
    }

    private async void OnSobreClicked(object sender, EventArgs e) =>
        await Navigation.PushAsync(new SobrePage());
}
